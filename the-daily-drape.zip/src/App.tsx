import { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { AboutSection } from './components/AboutSection';
import { FeaturedWorkSection } from './components/FeaturedWorkSection';
import { NailBoardSection } from './components/NailBoardSection';
import { ProcessSection } from './components/ProcessSection';
import { CaseStudiesSection } from './components/CaseStudiesSection';
import { ConnectSection } from './components/ConnectSection';
import { Footer } from './components/Footer';
import { SocialUrlModal } from './components/SocialUrlModal';
import { LookbookModal } from './components/LookbookModal';
import { NailModal } from './components/NailModal';
import { defaultSocialLinks } from './data/brandData';
import { SocialLinks, CuratedItem, NailItem } from './types';

export default function App() {
  const [socialLinks, setSocialLinks] = useState<SocialLinks>(() => {
    try {
      const saved = localStorage.getItem('the_daily_drape_socials');
      if (saved) {
        const parsed = JSON.parse(saved);
        // If saved links were the old placeholder links, upgrade to the user's official URLs
        if (
          parsed.pinterestUrl?.includes('pinterest.com/thedailydrape') ||
          parsed.threadsUrl?.includes('threads.net/@thedailydrape')
        ) {
          return defaultSocialLinks;
        }
        return parsed;
      }
    } catch {
      // Fallback
    }
    return defaultSocialLinks;
  });

  const [isSocialModalOpen, setIsSocialModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<CuratedItem | null>(null);
  const [selectedNail, setSelectedNail] = useState<NailItem | null>(null);

  const handleSaveSocials = (updated: SocialLinks) => {
    setSocialLinks(updated);
    try {
      localStorage.setItem('the_daily_drape_socials', JSON.stringify(updated));
    } catch {
      // Ignore
    }
  };

  useEffect(() => {
    // Keep document title synced
    document.title = 'The Daily Drape — Curated Aesthetics, Drapes & Nails for Pinterest & Threads';
  }, []);

  return (
    <div className="min-h-screen bg-[#120508] text-[#ecd0c3] selection:bg-[#c58b77] selection:text-[#120508] relative font-sans-clean">
      {/* Top Navigation */}
      <Navbar
        socialLinks={socialLinks}
        onOpenSocialModal={() => setIsSocialModalOpen(true)}
      />

      {/* Main Content Sections */}
      <main>
        {/* 1. Hero Section */}
        <HeroSection
          socialLinks={socialLinks}
          onOpenSocialModal={() => setIsSocialModalOpen(true)}
        />

        {/* 2. About Section with 3 Stat Cards */}
        <AboutSection socialLinks={socialLinks} />

        {/* 3. Featured Work / Curations 4-Card Grid */}
        <FeaturedWorkSection
          socialLinks={socialLinks}
          onSelectItem={(item) => setSelectedItem(item)}
        />

        {/* 4. The Nail Atelier & Moodboard Section */}
        <NailBoardSection
          socialLinks={socialLinks}
          onSelectNail={(nail) => setSelectedNail(nail)}
        />

        {/* 5. 5-Step Process Section */}
        <ProcessSection />

        {/* 6. Selected Spotlights / Case Studies */}
        <CaseStudiesSection
          socialLinks={socialLinks}
          onOpenSocialModal={() => setIsSocialModalOpen(true)}
        />

        {/* 7. Connect / Social Hub Banner */}
        <ConnectSection
          socialLinks={socialLinks}
          onOpenSocialModal={() => setIsSocialModalOpen(true)}
        />
      </main>

      {/* Footer */}
      <Footer
        socialLinks={socialLinks}
        onOpenSocialModal={() => setIsSocialModalOpen(true)}
      />

      {/* Modals */}
      <SocialUrlModal
        isOpen={isSocialModalOpen}
        onClose={() => setIsSocialModalOpen(false)}
        socialLinks={socialLinks}
        onSave={handleSaveSocials}
      />

      <LookbookModal
        item={selectedItem}
        onClose={() => setSelectedItem(null)}
        socialLinks={socialLinks}
      />

      <NailModal
        nail={selectedNail}
        onClose={() => setSelectedNail(null)}
        socialLinks={socialLinks}
      />
    </div>
  );
}

