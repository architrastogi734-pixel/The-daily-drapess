import React, { useState, useEffect } from 'react';
import { ArrowRight, Menu, X } from 'lucide-react';
import { SocialLinks } from '../types';

interface NavbarProps {
  onOpenSocialModal: () => void;
  socialLinks: SocialLinks;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenSocialModal,
  socialLinks,
}) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('hero');

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);

      // Detect active section
      const sections = ['hero', 'about', 'work', 'nails', 'process', 'contact'];
      const scrollPosition = window.scrollY + 120;
      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'HOME', href: '#hero', id: 'hero' },
    { label: 'ABOUT', href: '#about', id: 'about' },
    { label: 'WORK', href: '#work', id: 'work' },
    { label: 'PROCESS', href: '#process', id: 'process' },
    { label: 'CONTACT', href: '#contact', id: 'contact' },
  ];

  const handleOpenLink = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-[#120407]/90 backdrop-blur-md py-4 border-b border-[#3c1219]/60 shadow-2xl shadow-black/60'
          : 'bg-transparent py-7'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-10 lg:px-12 flex items-center justify-between">
        {/* Left: Brand Logo in exact editorial format */}
        <a href="#hero" className="group flex flex-col text-left transition-opacity hover:opacity-90">
          <span className="font-editorial text-2xl sm:text-[26px] tracking-[0.22em] text-[#ecd0c3] uppercase font-normal leading-none group-hover:text-[#d49887] transition-colors">
            THE DAILY DRAPES
          </span>
          <span className="text-[9px] tracking-[0.42em] text-[#a67c74] uppercase font-sans-clean mt-1 font-medium">
            DESIGN STUDIO
          </span>
        </a>

        {/* Center: Clean Nav Links with Active Dot */}
        <nav className="hidden md:flex items-center space-x-9 lg:space-x-11 text-xs font-medium tracking-[0.24em] text-[#c59e94]">
          {navLinks.map((link) => {
            const isActive = activeSection === link.id;
            return (
              <a
                key={link.label}
                href={link.href}
                className={`relative py-1 transition-colors duration-200 flex flex-col items-center group ${
                  isActive ? 'text-[#f3ded2] font-semibold' : 'hover:text-[#ecd0c3]'
                }`}
              >
                <span>{link.label}</span>
                {isActive ? (
                  <span className="w-1 h-1 bg-[#d49887] rounded-full absolute -bottom-1" />
                ) : (
                  <span className="w-1 h-1 bg-transparent group-hover:bg-[#d49887]/50 rounded-full absolute -bottom-1 transition-colors" />
                )}
              </a>
            );
          })}
        </nav>

        {/* Right: Pill Button "LET'S TALK ->" */}
        <div className="hidden md:flex items-center">
          <a
            href="#contact"
            className="group inline-flex items-center gap-2.5 px-6 py-2.5 rounded-full border border-[#4a1722] hover:border-[#d49887] bg-[#1a060b]/40 hover:bg-[#d49887] text-[#ecd0c3] hover:text-[#120407] text-xs font-medium tracking-[0.2em] uppercase transition-all duration-300 shadow-sm active:scale-95"
          >
            <span>LET'S TALK</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </a>
        </div>

        {/* Mobile Hamburger */}
        <div className="flex md:hidden items-center">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-[#ecd0c3] hover:text-[#d49887] transition-colors"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#160509]/98 backdrop-blur-xl border-b border-[#3c1219] px-7 py-8 space-y-6 shadow-2xl">
          <nav className="flex flex-col space-y-5 text-sm tracking-[0.25em] text-[#c59e94]">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`py-1 transition-colors ${
                  activeSection === link.id ? 'text-[#f3ded2] font-semibold' : 'hover:text-[#ecd0c3]'
                }`}
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div className="pt-5 border-t border-[#3c1219]/60 flex flex-col gap-3">
            <a
              href="#contact"
              onClick={() => setMobileMenuOpen(false)}
              className="inline-flex items-center justify-center gap-2.5 px-6 py-3 bg-[#d49887] text-[#120407] rounded-full text-xs font-semibold uppercase tracking-[0.2em] shadow-lg"
            >
              <span>LET'S TALK</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </a>

            <div className="flex items-center justify-between pt-2 text-[11px] uppercase tracking-wider text-[#a67c74]">
              <button
                onClick={() => {
                  handleOpenLink(socialLinks.pinterestUrl);
                  setMobileMenuOpen(false);
                }}
                className="hover:text-[#ecd0c3] underline underline-offset-4"
              >
                Pinterest Boards
              </button>
              <button
                onClick={() => {
                  handleOpenLink(socialLinks.threadsUrl);
                  setMobileMenuOpen(false);
                }}
                className="hover:text-[#ecd0c3] underline underline-offset-4"
              >
                Threads Profile
              </button>
              <button
                onClick={() => {
                  onOpenSocialModal();
                  setMobileMenuOpen(false);
                }}
                className="hover:text-[#ecd0c3]"
              >
                Settings
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
