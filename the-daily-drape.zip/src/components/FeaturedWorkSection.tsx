import React from 'react';
import { ArrowRight, ArrowUpRight, Bookmark } from 'lucide-react';
import { CuratedItem, SocialLinks } from '../types';
import { curatedLookbooks } from '../data/brandData';

interface FeaturedWorkSectionProps {
  socialLinks: SocialLinks;
  onSelectItem: (item: CuratedItem) => void;
}

export const FeaturedWorkSection: React.FC<FeaturedWorkSectionProps> = ({
  socialLinks,
  onSelectItem,
}) => {
  const handleOpenPinterest = () => {
    window.open(socialLinks.pinterestUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="work" className="py-20 lg:py-28 bg-[#140407] relative">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-12 border-b border-[#3c1219]/60 pb-6">
          <div className="flex items-center gap-3">
            <span className="text-xs uppercase tracking-[0.28em] text-[#d49887] font-medium font-sans-clean">
              FEATURED WORK
            </span>
            <span className="w-12 h-px bg-[#d49887]/60" />
          </div>

          <button
            onClick={handleOpenPinterest}
            className="group inline-flex items-center gap-2 text-xs uppercase tracking-[0.22em] text-[#ecd0c3] hover:text-[#d49887] transition-colors"
          >
            <span>VIEW ALL PROJECTS</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* 4 Cards Grid matching screenshot */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {curatedLookbooks.map((item) => (
            <div
              key={item.id}
              onClick={() => onSelectItem(item)}
              className="group cursor-pointer flex flex-col text-left"
            >
              {/* Image Frame */}
              <div className="relative aspect-square w-full rounded-xl overflow-hidden bg-[#1f0a0e] border border-[#3c1219] group-hover:border-[#d49887]/50 transition-all duration-500 shadow-md">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                  <span className="inline-flex items-center gap-1 text-[11px] uppercase tracking-wider text-[#ecd0c3] font-medium bg-[#140508]/80 backdrop-blur-xs px-3 py-1.5 rounded-full border border-[#d49887]/40">
                    <Bookmark className="w-3 h-3 text-[#d49887]" />
                    <span>View Look & Shop</span>
                    <ArrowUpRight className="w-3 h-3" />
                  </span>
                </div>
              </div>

              {/* Title & Category Underneath */}
              <div className="mt-4 flex flex-col">
                <h4 className="font-serif text-lg text-[#ecd0c3] group-hover:text-[#d49887] tracking-wider transition-colors">
                  {item.title}
                </h4>
                <p className="text-xs text-[#a67c74] tracking-wide mt-0.5 font-sans-clean">
                  {item.category}
                </p>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
