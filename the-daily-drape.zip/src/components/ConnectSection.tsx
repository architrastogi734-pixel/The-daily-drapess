import React from 'react';
import { ArrowRight, Mail, AtSign, MapPin, ExternalLink, SlidersHorizontal, Bookmark } from 'lucide-react';
import { CircularStamp } from './CircularStamp';
import { brandImages } from '../data/brandData';
import { SocialLinks } from '../types';

interface ConnectSectionProps {
  socialLinks: SocialLinks;
  onOpenSocialModal: () => void;
}

export const ConnectSection: React.FC<ConnectSectionProps> = ({
  socialLinks,
  onOpenSocialModal,
}) => {
  const handleOpenPinterest = () => {
    window.open(socialLinks.pinterestUrl, '_blank', 'noopener,noreferrer');
  };

  const handleOpenThreads = () => {
    window.open(socialLinks.threadsUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="contact" className="py-16 lg:py-24 bg-[#120508] relative">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        
        {/* Main Burgundy Banner Card matching screenshot */}
        <div className="relative rounded-3xl bg-[#280d14] border border-[#d49887]/30 p-8 sm:p-12 lg:p-16 overflow-hidden shadow-2xl">
          
          {/* Ambient lighting inside card */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#4e1622]/40 rounded-full blur-3xl pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center relative z-10">
            
            {/* Left Side: Call to Action */}
            <div className="lg:col-span-7 flex flex-col text-left">
              <div className="flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-[#d49887] font-medium mb-4">
                <span>LET'S CONNECT</span>
                <span className="w-8 h-px bg-[#d49887]/60" />
              </div>

              <h2 className="font-editorial text-4xl sm:text-5xl lg:text-6xl text-[#f3ded2] leading-[1.05] tracking-tight mb-5">
                Ready to elevate <span className="italic font-normal text-[#d49887]">your brand?</span>
              </h2>

              <p className="text-sm sm:text-base text-[#c59e94] max-w-xl leading-relaxed mb-8 font-light">
                Let's create something beautiful, strategic, and unforgettable.
                Explore our full portfolios and aesthetic lookbooks directly on Pinterest and Threads.
              </p>

              <div className="flex flex-wrap items-center gap-4">
                <button
                  onClick={handleOpenThreads}
                  className="group inline-flex items-center gap-3 px-8 py-3.5 bg-[#d49887] hover:bg-[#ecd0c3] text-[#140508] rounded-full text-xs font-semibold tracking-[0.16em] uppercase transition-all duration-300 shadow-md active:scale-95"
                >
                  <span>LET'S WORK TOGETHER</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>

                <button
                  onClick={handleOpenPinterest}
                  className="inline-flex items-center gap-2 px-6 py-3.5 bg-[#1a080c] hover:bg-[#280d12] border border-[#d49887]/40 text-[#ecd0c3] rounded-full text-xs font-medium tracking-[0.16em] uppercase transition-all duration-300 active:scale-95"
                >
                  <Bookmark className="w-3.5 h-3.5 fill-current text-[#d49887]" />
                  <span>PINTEREST BOARD</span>
                </button>
              </div>
            </div>

            {/* Right Side: Contact Channels & Rotating Stamp */}
            <div className="lg:col-span-5 flex flex-col justify-between space-y-6 lg:pl-8 lg:border-l lg:border-[#3c1219]/70">
              
              {/* Contact Information List matching screenshot */}
              <div className="space-y-4">
                
                <a
                  href={socialLinks.pinterestUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 group text-[#ecd0c3] hover:text-[#d49887] transition-colors pb-3 border-b border-[#3c1219]/60"
                >
                  <div className="w-8 h-8 rounded-full bg-[#1c080d] flex items-center justify-center text-[#d49887]">
                    <Bookmark className="w-4 h-4" />
                  </div>
                  <span className="text-xs sm:text-sm tracking-wider font-light break-all">
                    {socialLinks.pinterestUrl.replace(/^https?:\/\//, '')}
                  </span>
                  <ExternalLink className="w-3.5 h-3.5 ml-auto opacity-60 group-hover:opacity-100" />
                </a>

                <a
                  href={socialLinks.threadsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 group text-[#ecd0c3] hover:text-[#d49887] transition-colors pb-3 border-b border-[#3c1219]/60"
                >
                  <div className="w-8 h-8 rounded-full bg-[#1c080d] flex items-center justify-center text-[#d49887]">
                    <AtSign className="w-4 h-4" />
                  </div>
                  <span className="text-xs sm:text-sm tracking-wider font-light break-all">
                    {socialLinks.threadsUrl.replace(/^https?:\/\//, '')}
                  </span>
                  <ExternalLink className="w-3.5 h-3.5 ml-auto opacity-60 group-hover:opacity-100" />
                </a>

                <div className="flex items-center gap-3 text-[#c59e94] pb-3 border-b border-[#3c1219]/60">
                  <div className="w-8 h-8 rounded-full bg-[#1c080d] flex items-center justify-center text-[#d49887]">
                    <Mail className="w-4 h-4" />
                  </div>
                  <span className="text-xs sm:text-sm tracking-wider font-light">
                    {socialLinks.email || 'curations@thedailydrape.com'}
                  </span>
                </div>

                <div className="flex items-center gap-3 text-[#c59e94]">
                  <div className="w-8 h-8 rounded-full bg-[#1c080d] flex items-center justify-center text-[#d49887]">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <span className="text-xs sm:text-sm tracking-wider font-light">
                    {socialLinks.location || 'Paris • Milan • Digital Studio'}
                  </span>
                </div>

              </div>

              {/* Circular stamp */}
              <div className="flex justify-end pt-2">
                <CircularStamp
                  text="LET'S CREATE SOMETHING BEAUTIFUL"
                  icon="sparkles"
                  size={120}
                />
              </div>

            </div>

          </div>

          {/* Deep Crimson Velvet Peony Flower in Bottom Right matching screenshot */}
          <div className="absolute -bottom-16 -right-12 w-48 h-48 sm:w-64 sm:h-64 pointer-events-none opacity-85 z-0">
            <img
              src={brandImages.peonyFlower}
              alt="Deep burgundy flower bloom accent"
              className="w-full h-full object-contain filter drop-shadow-[0_20px_35px_rgba(0,0,0,0.9)]"
            />
          </div>

        </div>

      </div>
    </section>
  );
};
