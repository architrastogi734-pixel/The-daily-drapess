import React from 'react';
import { X, ExternalLink, Bookmark, MessageSquare, ArrowUpRight } from 'lucide-react';
import { CuratedItem, SocialLinks } from '../types';

interface LookbookModalProps {
  item: CuratedItem | null;
  onClose: () => void;
  socialLinks: SocialLinks;
}

export const LookbookModal: React.FC<LookbookModalProps> = ({
  item,
  onClose,
  socialLinks,
}) => {
  if (!item) return null;

  const handleOpenPinterest = () => {
    const target = item.pinterestBoardUrl || socialLinks.pinterestUrl;
    window.open(target, '_blank', 'noopener,noreferrer');
  };

  const handleOpenThreads = () => {
    const target = item.threadsPostUrl || socialLinks.threadsUrl;
    window.open(target, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-3xl bg-[#1a080c] border border-[#d49887]/30 rounded-2xl overflow-hidden shadow-2xl flex flex-col md:flex-row max-h-[90vh]">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 text-[#ecd0c3] bg-black/50 hover:bg-black/80 rounded-full transition-colors"
          aria-label="Close lookbook modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Image Column */}
        <div className="md:w-1/2 relative bg-[#120508] min-h-[260px] md:min-h-[460px] overflow-hidden flex items-center justify-center">
          <img
            src={item.image}
            alt={item.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1a080c] via-transparent to-black/20" />
          <div className="absolute bottom-4 left-4 right-4">
            <span className="inline-block px-3 py-1 bg-black/60 backdrop-blur-xs border border-[#d49887]/40 text-[#ecd0c3] text-[10px] tracking-widest uppercase rounded-full">
              {item.category}
            </span>
          </div>
        </div>

        {/* Content Column */}
        <div className="md:w-1/2 p-6 md:p-8 flex flex-col justify-between overflow-y-auto">
          <div>
            <div className="text-xs uppercase tracking-[0.25em] text-[#d49887] font-medium mb-1">
              Curated Silhouette
            </div>
            <h3 className="font-serif text-3xl md:text-4xl text-[#ecd0c3] mb-3 tracking-wide">
              {item.title}
            </h3>

            {item.featuredQuote && (
              <p className="font-serif italic text-sm text-[#d49887] mb-4 border-l-2 border-[#d49887]/60 pl-3">
                "{item.featuredQuote}"
              </p>
            )}

            <p className="text-sm text-[#c59e94] leading-relaxed mb-5">
              {item.description}
            </p>

            <div className="bg-[#240c12] border border-[#3c1219] rounded-xl p-4 mb-6">
              <div className="text-xs font-semibold uppercase tracking-wider text-[#d49887] mb-1">
                Fabric & Silhouette Notes
              </div>
              <p className="text-xs text-[#ecd0c3]/80">
                {item.tags}
              </p>
            </div>
          </div>

          {/* Action Destination */}
          <div className="space-y-3 pt-4 border-t border-[#3c1219]">
            <p className="text-xs text-[#a67c74]">
              Where to buy & inspect sources:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                onClick={handleOpenPinterest}
                className="flex items-center justify-center gap-2 px-4 py-2.5 bg-[#d49887] hover:bg-[#ecd0c3] text-[#1a080c] rounded-full text-xs font-semibold tracking-wider uppercase transition-all shadow-md active:scale-95"
              >
                <Bookmark className="w-3.5 h-3.5 fill-current" />
                <span>Shop on Pinterest</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={handleOpenThreads}
                className="flex items-center justify-center gap-2 px-4 py-2.5 bg-[#2a0e14] hover:bg-[#3d141d] border border-[#d49887]/40 text-[#ecd0c3] rounded-full text-xs font-medium tracking-wider uppercase transition-all active:scale-95"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Chat on Threads</span>
                <ExternalLink className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
