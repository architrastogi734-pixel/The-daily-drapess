import React from 'react';
import { SocialLinks } from '../types';

interface FooterProps {
  socialLinks: SocialLinks;
  onOpenSocialModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  socialLinks,
  onOpenSocialModal,
}) => {
  return (
    <footer className="bg-[#0e0406] border-t border-[#3c1219]/60 py-10 text-[#a67c74] text-xs">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
        
        {/* Brand Name */}
        <div className="flex flex-col text-center md:text-left">
          <span className="font-serif text-lg text-[#ecd0c3] tracking-[0.2em] uppercase font-normal">
            THE DAILY DRAPES
          </span>
          <span className="text-[9px] tracking-[0.3em] uppercase text-[#d49887]">
            DESIGN & CURATION STUDIO
          </span>
        </div>

        {/* Copyright */}
        <div className="text-center font-light tracking-wider text-[11px] text-[#8e655e]">
          © {new Date().getFullYear()} The Daily Drapes. All rights reserved. Curated for Pinterest & Threads.
        </div>

        {/* Legal & Configuration Links */}
        <div className="flex items-center space-x-6 text-[11px] uppercase tracking-widest">
          <a
            href={socialLinks.pinterestUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-[#ecd0c3] transition-colors"
          >
            Pinterest
          </a>
          <a
            href={socialLinks.threadsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-[#ecd0c3] transition-colors"
          >
            Threads
          </a>
          <button
            onClick={onOpenSocialModal}
            className="text-[#d49887] hover:text-[#ecd0c3] transition-colors cursor-pointer"
          >
            Edit URLs
          </button>
          <span className="text-[#3c1219]">•</span>
          <span className="text-[#6d4c46]">Privacy</span>
          <span className="text-[#6d4c46]">Terms</span>
        </div>

      </div>
    </footer>
  );
};
