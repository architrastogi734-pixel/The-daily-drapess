import React from 'react';
import { X, Bookmark, MessageSquare, ArrowUpRight, Sparkles, Paintbrush } from 'lucide-react';
import { NailItem, SocialLinks } from '../types';

interface NailModalProps {
  nail: NailItem | null;
  onClose: () => void;
  socialLinks: SocialLinks;
}

export const NailModal: React.FC<NailModalProps> = ({
  nail,
  onClose,
  socialLinks,
}) => {
  if (!nail) return null;

  const handleOpenPinterest = () => {
    const target = nail.pinterestUrl || socialLinks.pinterestUrl;
    window.open(target, '_blank', 'noopener,noreferrer');
  };

  const handleOpenThreads = () => {
    const target = nail.threadsUrl || socialLinks.threadsUrl;
    window.open(target, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-3xl bg-[#1a080c] border border-[#d49887]/35 rounded-2xl overflow-hidden shadow-2xl flex flex-col md:flex-row max-h-[90vh]">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 text-[#ecd0c3] bg-black/60 hover:bg-black/90 rounded-full transition-colors"
          aria-label="Close nail preview modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Image Column */}
        <div className="md:w-1/2 relative bg-[#120508] min-h-[280px] md:min-h-[460px] overflow-hidden flex items-center justify-center">
          <img
            src={nail.image}
            alt={nail.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1a080c] via-transparent to-black/20" />
          <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#140508]/85 backdrop-blur-xs border border-[#d49887]/40 text-[#ecd0c3] text-[10px] tracking-widest uppercase rounded-full font-medium">
              <Paintbrush className="w-3 h-3 text-[#d49887]" />
              {nail.shape}
            </span>
            <span className="text-[10px] tracking-widest uppercase text-[#d49887] font-medium bg-black/60 px-2.5 py-1 rounded-full border border-[#3c1219]">
              Nail Lookbook
            </span>
          </div>
        </div>

        {/* Content Details Column */}
        <div className="md:w-1/2 p-6 md:p-8 flex flex-col justify-between overflow-y-auto">
          <div>
            <div className="flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-[#d49887] font-medium mb-1">
              <Sparkles className="w-3.5 h-3.5 text-[#d49887]" />
              <span>Haute Nail Atelier</span>
            </div>

            <h3 className="font-serif text-2xl md:text-3xl text-[#ecd0c3] mb-2 tracking-wide">
              {nail.title}
            </h3>

            <div className="inline-block px-2.5 py-1 bg-[#280d14] border border-[#3c1219] rounded-lg text-xs text-[#d49887] font-medium tracking-wide mb-4">
              Finish: {nail.finish}
            </div>

            <p className="text-sm text-[#c59e94] leading-relaxed mb-5">
              {nail.description}
            </p>

            {/* Palette Breakdown */}
            <div className="bg-[#240c12] border border-[#3c1219] rounded-xl p-4 mb-6">
              <div className="text-xs font-semibold uppercase tracking-wider text-[#d49887] mb-1.5">
                Harmonized Palette & Tone
              </div>
              <p className="text-xs text-[#ecd0c3]/90 mb-3">
                {nail.palette}
              </p>
              <div className="flex items-center gap-2">
                <span className="w-4 h-4 rounded-full bg-[#4a0e17] border border-[#d49887]/40" title="Bordeaux Burgundy" />
                <span className="w-4 h-4 rounded-full bg-[#1b060a] border border-[#d49887]/40" title="Midnight Noir" />
                <span className="w-4 h-4 rounded-full bg-[#d49887] border border-white/20" title="Rose Champagne" />
                <span className="w-4 h-4 rounded-full bg-[#f4e2d8] border border-white/20" title="Glazed Pearl" />
                <span className="text-[10px] text-[#a67c74] uppercase tracking-wider ml-1">Curated Shades</span>
              </div>
            </div>
          </div>

          {/* Social Destination Buttons */}
          <div className="space-y-3 pt-4 border-t border-[#3c1219]">
            <p className="text-xs text-[#a67c74]">
              Explore inspiration, shades, & links on our official channels:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                onClick={handleOpenPinterest}
                className="flex items-center justify-center gap-2 px-4 py-2.5 bg-[#d49887] hover:bg-[#ecd0c3] text-[#1a080c] rounded-full text-xs font-semibold tracking-wider uppercase transition-all shadow-md active:scale-95"
              >
                <Bookmark className="w-3.5 h-3.5 fill-current" />
                <span>Save on Pinterest</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={handleOpenThreads}
                className="flex items-center justify-center gap-2 px-4 py-2.5 bg-[#2a0e14] hover:bg-[#3d141d] border border-[#d49887]/40 text-[#ecd0c3] rounded-full text-xs font-medium tracking-wider uppercase transition-all active:scale-95"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Discuss on Threads</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
