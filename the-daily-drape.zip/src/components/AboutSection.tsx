import React from 'react';
import { ArrowRight, Sparkles, Flower2, Bookmark } from 'lucide-react';
import { SocialLinks } from '../types';

interface AboutSectionProps {
  socialLinks: SocialLinks;
}

export const AboutSection: React.FC<AboutSectionProps> = ({
  socialLinks,
}) => {
  const handleOpenPinterest = () => {
    window.open(socialLinks.pinterestUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="about" className="py-20 lg:py-28 bg-[#150609] border-t border-[#3c1219]/40 relative overflow-hidden">
      {/* Subtle background element */}
      <div className="absolute top-1/2 left-0 w-72 h-72 bg-[#3b121a]/20 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Left Column: Story & Philosophy */}
          <div className="lg:col-span-5 flex flex-col justify-center">
            <div className="flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-[#d49887] font-medium mb-3">
              <span>ABOUT ME</span>
              <span className="w-8 h-px bg-[#d49887]/60" />
            </div>

            <h2 className="font-editorial text-4xl sm:text-5xl lg:text-6xl text-[#ecd0c3] leading-[1.05] tracking-tight mb-6">
              Strategy meets <span className="italic font-normal text-[#d49887]">creativity.</span>
            </h2>

            <p className="text-sm sm:text-base text-[#c59e94] leading-relaxed mb-6 font-light">
              I'm Mariana, a brand and web designer passionate about creating meaningful,
              visually captivating experiences. I help businesses turn ideas into identities
              that connect and convert.
            </p>

            <p className="text-sm text-[#a67c74] leading-relaxed mb-8">
              Explore my curated boards and lookbooks on{' '}
              <span className="text-[#ecd0c3] font-medium">Pinterest</span> for aesthetic references and
              shoppable inspiration, and join our conversation on{' '}
              <span className="text-[#ecd0c3] font-medium">Threads</span>.
            </p>

            <div>
              <button
                onClick={handleOpenPinterest}
                className="group inline-flex items-center gap-3 px-7 py-3 bg-[#240b12] hover:bg-[#34111a] border border-[#d49887]/50 rounded-full text-xs font-semibold uppercase tracking-[0.18em] text-[#ecd0c3] hover:text-[#f3ded2] transition-all duration-300 active:scale-95"
              >
                <span>MORE ABOUT ME</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform text-[#d49887]" />
              </button>
            </div>
          </div>

          {/* Right Column: 3 Metric Cards matching screenshot */}
          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-3 gap-5">
            
            {/* Card 1 */}
            <div className="bg-[#240a10] border border-[#3c1219] hover:border-[#d49887]/40 rounded-2xl p-6 sm:p-7 flex flex-col justify-between transition-all duration-300 hover:shadow-xl hover:shadow-[#3c1219]/20 group min-h-[220px]">
              <div>
                <div className="w-10 h-10 rounded-full bg-[#2f0e16] flex items-center justify-center text-[#d49887] mb-6 group-hover:scale-110 transition-transform">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div className="font-display text-4xl lg:text-5xl text-[#f3ded2] font-semibold tracking-tight mb-2">
                  5+
                </div>
                <div className="text-xs uppercase tracking-widest text-[#d49887] font-medium mb-3">
                  Years Experience
                </div>
              </div>
              <p className="text-xs text-[#a67c74] leading-relaxed">
                Crafting brands and digital experiences that make an impact.
              </p>
            </div>

            {/* Card 2 */}
            <div className="bg-[#240a10] border border-[#3c1219] hover:border-[#d49887]/40 rounded-2xl p-6 sm:p-7 flex flex-col justify-between transition-all duration-300 hover:shadow-xl hover:shadow-[#3c1219]/20 group min-h-[220px]">
              <div>
                <div className="w-10 h-10 rounded-full bg-[#2f0e16] flex items-center justify-center text-[#d49887] mb-6 group-hover:scale-110 transition-transform">
                  <Flower2 className="w-5 h-5" />
                </div>
                <div className="font-display text-4xl lg:text-5xl text-[#f3ded2] font-semibold tracking-tight mb-2">
                  100+
                </div>
                <div className="text-xs uppercase tracking-widest text-[#d49887] font-medium mb-3">
                  Projects Completed
                </div>
              </div>
              <p className="text-xs text-[#a67c74] leading-relaxed">
                From startups to established brands, results that speak.
              </p>
            </div>

            {/* Card 3 */}
            <div className="bg-[#240a10] border border-[#3c1219] hover:border-[#d49887]/40 rounded-2xl p-6 sm:p-7 flex flex-col justify-between transition-all duration-300 hover:shadow-xl hover:shadow-[#3c1219]/20 group min-h-[220px]">
              <div>
                <div className="w-10 h-10 rounded-full bg-[#2f0e16] flex items-center justify-center text-[#d49887] mb-6 group-hover:scale-110 transition-transform">
                  <Bookmark className="w-5 h-5" />
                </div>
                <div className="font-serif text-lg lg:text-xl text-[#f3ded2] font-medium tracking-tight mb-2 leading-snug">
                  Brand Strategy & Design Expert
                </div>
              </div>
              <p className="text-xs text-[#a67c74] leading-relaxed mt-4">
                Turning ideas into visual stories that resonate.
              </p>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
