import React from 'react';
import { curationProcessSteps } from '../data/brandData';

export const ProcessSection: React.FC = () => {
  return (
    <section id="process" className="py-20 lg:py-28 bg-[#150609] border-t border-[#3c1219]/40 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        
        {/* Section Header */}
        <div className="flex items-center gap-3 mb-16">
          <span className="text-xs uppercase tracking-[0.25em] text-[#d49887] font-medium">
            MY DESIGN PROCESS
          </span>
          <span className="w-10 h-px bg-[#d49887]/60" />
        </div>

        {/* 5-Step Process Timeline matching screenshot */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8 relative">
          
          {curationProcessSteps.map((step, idx) => (
            <div key={step.stepNumber} className="relative flex flex-col text-left group">
              
              {/* Number and Step Connector */}
              <div className="flex items-center gap-3 mb-4">
                <span className="font-editorial text-4xl sm:text-5xl text-[#d49887] group-hover:text-[#ecd0c3] transition-colors leading-none">
                  {step.stepNumber}
                </span>

                {/* Horizontal divider line to next step for desktop */}
                {idx < curationProcessSteps.length - 1 && (
                  <div className="hidden md:flex items-center flex-1 pr-2">
                    <span className="h-px bg-[#3c1219] group-hover:bg-[#d49887]/50 w-full transition-colors" />
                    <span className="w-1.5 h-1.5 rounded-full bg-[#d49887]/60 ml-1 shrink-0" />
                  </div>
                )}
              </div>

              {/* Step Title */}
              <h4 className="text-xs uppercase tracking-[0.2em] text-[#ecd0c3] font-semibold mb-2">
                {step.title}
              </h4>

              {/* Step Description */}
              <p className="text-xs text-[#a67c74] leading-relaxed">
                {step.description}
              </p>
            </div>
          ))}

        </div>

      </div>
    </section>
  );
};
