import React from 'react';
import { Sparkles, Flower2 } from 'lucide-react';

interface CircularStampProps {
  text: string;
  className?: string;
  icon?: 'flower' | 'sparkles';
  size?: number;
}

export const CircularStamp: React.FC<CircularStampProps> = ({
  text,
  className = '',
  icon = 'flower',
  size = 130,
}) => {
  const radius = 50;
  const viewBoxSize = 120;
  const center = viewBoxSize / 2;

  return (
    <div
      className={`relative flex items-center justify-center select-none ${className}`}
      style={{ width: size, height: size }}
    >
      {/* Rotating text ring */}
      <svg
        viewBox={`0 0 ${viewBoxSize} ${viewBoxSize}`}
        className="w-full h-full animate-spin-slow"
      >
        <path
          id={`stamp-path-${text.replace(/\s+/g, '-').toLowerCase()}`}
          d={`M ${center}, ${center} m -${radius}, 0 a ${radius},${radius} 0 1,1 ${radius * 2},0 a ${radius},${radius} 0 1,1 -${radius * 2},0`}
          fill="none"
        />
        <text
          fill="#d49887"
          fontSize="8.5"
          fontFamily="'Plus Jakarta Sans', sans-serif"
          letterSpacing="0.22em"
          fontWeight="500"
          className="uppercase"
        >
          <textPath
            href={`#stamp-path-${text.replace(/\s+/g, '-').toLowerCase()}`}
            startOffset="0%"
          >
            {text} •
          </textPath>
        </text>
      </svg>

      {/* Center icon in circle */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-10 h-10 rounded-full border border-[#d49887]/30 bg-[#1f0a0e]/80 backdrop-blur-xs flex items-center justify-center shadow-inner">
          {icon === 'flower' ? (
            <Flower2 className="w-5 h-5 text-[#d49887]" strokeWidth={1.5} />
          ) : (
            <Sparkles className="w-4 h-4 text-[#d49887]" strokeWidth={1.5} />
          )}
        </div>
      </div>
    </div>
  );
};
