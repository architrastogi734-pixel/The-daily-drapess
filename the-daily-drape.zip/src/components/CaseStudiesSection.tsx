import React from 'react';
import { ArrowRight } from 'lucide-react';
import { SpotlightItem, SocialLinks } from '../types';
import { spotlightItems } from '../data/brandData';

interface CaseStudiesSectionProps {
  socialLinks: SocialLinks;
  onOpenSocialModal: () => void;
}

export const CaseStudiesSection: React.FC<CaseStudiesSectionProps> = ({
  socialLinks,
}) => {
  const handleOpenPlatform = (item: SpotlightItem) => {
    const targetUrl =
      item.targetPlatform === 'pinterest'
        ? socialLinks.pinterestUrl
        : socialLinks.threadsUrl;
    window.open(targetUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="case-studies" className="py-20 lg:py-28 bg-[#130407] relative">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-12 border-b border-[#3c1219]/60 pb-6">
          <div className="flex items-center gap-3">
            <span className="text-xs uppercase tracking-[0.28em] text-[#d49887] font-medium font-sans-clean">
              SELECTED CASE STUDIES
            </span>
            <span className="w-12 h-px bg-[#d49887]/60" />
          </div>

          <button
            onClick={() => window.open(socialLinks.pinterestUrl, '_blank', 'noopener,noreferrer')}
            className="group inline-flex items-center gap-2 text-xs uppercase tracking-[0.22em] text-[#ecd0c3] hover:text-[#d49887] transition-colors"
          >
            <span>VIEW CASE STUDIES</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* 2 Wide Split Spotlight Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {spotlightItems.map((item) => (
            <div
              key={item.id}
              className="bg-[#240a10] border border-[#3c1219] hover:border-[#d49887]/50 rounded-2xl overflow-hidden transition-all duration-500 flex flex-col sm:flex-row group shadow-xl"
            >
              {/* Text Information Column */}
              <div className="sm:w-1/2 p-8 sm:p-9 flex flex-col justify-between text-left">
                <div>
                  <h3 className="font-editorial text-3xl sm:text-4xl text-[#f3ded2] tracking-wide mb-3 uppercase leading-[1.05]">
                    {item.title}
                  </h3>
                  <p className="text-sm text-[#c59e94] leading-relaxed mb-6 font-light">
                    {item.subtitle}
                  </p>
                </div>

                <div>
                  <button
                    onClick={() => handleOpenPlatform(item)}
                    className="group/btn inline-flex items-center gap-2.5 text-xs uppercase tracking-[0.2em] text-[#d49887] hover:text-[#f3ded2] font-semibold transition-colors"
                  >
                    <span>VIEW PROJECT</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover/btn:translate-x-1.5 transition-transform" />
                  </button>
                </div>
              </div>

              {/* Image Column */}
              <div className="sm:w-1/2 relative min-h-[240px] sm:min-h-[280px] overflow-hidden bg-[#120508]">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                />
                <div className="absolute inset-0 bg-gradient-to-t sm:bg-gradient-to-r from-[#240a10] via-transparent to-transparent opacity-50" />
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
