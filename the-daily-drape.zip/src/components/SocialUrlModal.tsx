import React, { useState } from 'react';
import { X, ExternalLink, Check, Link2, Sparkles } from 'lucide-react';
import { SocialLinks } from '../types';

interface SocialUrlModalProps {
  isOpen: boolean;
  onClose: () => void;
  socialLinks: SocialLinks;
  onSave: (updated: SocialLinks) => void;
}

export const SocialUrlModal: React.FC<SocialUrlModalProps> = ({
  isOpen,
  onClose,
  socialLinks,
  onSave,
}) => {
  const [pinterestUrl, setPinterestUrl] = useState(socialLinks.pinterestUrl);
  const [threadsUrl, setThreadsUrl] = useState(socialLinks.threadsUrl);
  const [instagramUrl, setInstagramUrl] = useState(socialLinks.instagramUrl || '');
  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...socialLinks,
      pinterestUrl: pinterestUrl.trim() || 'https://pinterest.com',
      threadsUrl: threadsUrl.trim() || 'https://threads.net',
      instagramUrl: instagramUrl.trim(),
    });
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 1200);
  };

  const handleTestLink = (url: string) => {
    if (url) {
      window.open(url, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-lg bg-[#1a080c] border border-[#d49887]/30 rounded-2xl p-6 sm:p-8 shadow-2xl text-[#ecd0c3]">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-[#a67c74] hover:text-[#ecd0c3] rounded-full hover:bg-[#2b0d14] transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Title */}
        <div className="flex items-center gap-3 mb-2">
          <div className="w-9 h-9 rounded-full bg-[#3c1219] flex items-center justify-center text-[#d49887]">
            <Link2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-serif text-2xl text-[#ecd0c3] tracking-wide">
              Connect Your Social Channels
            </h3>
            <p className="text-xs text-[#a67c74]">
              Where visitors go to explore lookbooks & buy your curated pieces
            </p>
          </div>
        </div>

        <p className="text-sm text-[#c59e94] mb-6 leading-relaxed">
          Provide your official Pinterest and Threads URLs. All buttons across the website
          will instantly link to your accounts.
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Pinterest Input */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs uppercase tracking-widest text-[#d49887] font-medium">
                Pinterest URL / Board
              </label>
              {pinterestUrl && (
                <button
                  type="button"
                  onClick={() => handleTestLink(pinterestUrl)}
                  className="inline-flex items-center gap-1 text-xs text-[#d49887] hover:text-[#ecd0c3] transition-colors"
                >
                  <span>Test Link</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              )}
            </div>
            <div className="relative">
              <input
                type="url"
                required
                value={pinterestUrl}
                onChange={(e) => setPinterestUrl(e.target.value)}
                placeholder="https://pinterest.com/thedailydrape"
                className="w-full bg-[#120508] border border-[#3c1219] focus:border-[#d49887] rounded-xl px-4 py-2.5 text-sm text-[#ecd0c3] placeholder-[#663b43] focus:outline-none focus:ring-1 focus:ring-[#d49887] transition-all"
              />
            </div>
          </div>

          {/* Threads Input */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs uppercase tracking-widest text-[#d49887] font-medium">
                Threads URL / Profile
              </label>
              {threadsUrl && (
                <button
                  type="button"
                  onClick={() => handleTestLink(threadsUrl)}
                  className="inline-flex items-center gap-1 text-xs text-[#d49887] hover:text-[#ecd0c3] transition-colors"
                >
                  <span>Test Link</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              )}
            </div>
            <div className="relative">
              <input
                type="url"
                required
                value={threadsUrl}
                onChange={(e) => setThreadsUrl(e.target.value)}
                placeholder="https://threads.net/@thedailydrape"
                className="w-full bg-[#120508] border border-[#3c1219] focus:border-[#d49887] rounded-xl px-4 py-2.5 text-sm text-[#ecd0c3] placeholder-[#663b43] focus:outline-none focus:ring-1 focus:ring-[#d49887] transition-all"
              />
            </div>
          </div>

          {/* Optional Instagram */}
          <div>
            <label className="block text-xs uppercase tracking-widest text-[#a67c74] font-medium mb-1.5">
              Instagram / Lookbook (Optional)
            </label>
            <input
              type="url"
              value={instagramUrl}
              onChange={(e) => setInstagramUrl(e.target.value)}
              placeholder="https://instagram.com/thedailydrape"
              className="w-full bg-[#120508] border border-[#3c1219] focus:border-[#d49887] rounded-xl px-4 py-2.5 text-sm text-[#ecd0c3] placeholder-[#663b43] focus:outline-none focus:ring-1 focus:ring-[#d49887] transition-all"
            />
          </div>

          {/* Form Actions */}
          <div className="pt-4 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-full text-sm text-[#a67c74] hover:text-[#ecd0c3] hover:bg-[#280d12] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={savedSuccess}
              className="inline-flex items-center gap-2 px-6 py-2.5 bg-[#d49887] hover:bg-[#ecd0c3] text-[#1a080c] font-medium text-sm rounded-full transition-all shadow-md active:scale-95"
            >
              {savedSuccess ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Saved!</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Update URLs</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
