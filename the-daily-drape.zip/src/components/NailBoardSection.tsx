import React, { useState } from 'react';
import { ArrowRight, Bookmark, MessageSquare, ArrowUpRight, Sparkles, Heart } from 'lucide-react';
import { NailItem, SocialLinks } from '../types';
import { nailCurations } from '../data/brandData';

interface NailBoardSectionProps {
  socialLinks: SocialLinks;
  onSelectNail: (nail: NailItem) => void;
}

export const NailBoardSection: React.FC<NailBoardSectionProps> = ({
  socialLinks,
  onSelectNail,
}) => {
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [likedIds, setLikedIds] = useState<Record<string, boolean>>({});

  const filterOptions = [
    { id: 'all', label: 'All Curations' },
    { id: 'velvet', label: 'Velvet Cat-Eye' },
    { id: 'glazed', label: 'Glazed Chrome' },
    { id: 'noir', label: 'Dark Ombré' },
    { id: 'mocha', label: 'Cherry Mocha' },
  ];

  const filteredNails = nailCurations.filter((nail) => {
    if (activeFilter === 'all') return true;
    if (activeFilter === 'velvet') return nail.id.includes('velvet') || nail.id.includes('burgundy');
    if (activeFilter === 'glazed') return nail.id.includes('glazed');
    if (activeFilter === 'noir') return nail.id.includes('noir');
    if (activeFilter === 'mocha') return nail.id.includes('mocha');
    return true;
  });

  const toggleLike = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setLikedIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleOpenPinterest = () => {
    window.open(socialLinks.pinterestUrl, '_blank', 'noopener,noreferrer');
  };

  const handleOpenThreads = () => {
    window.open(socialLinks.threadsUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="nails" className="py-20 lg:py-28 bg-[#150609] border-t border-[#3c1219]/40 relative overflow-hidden">
      {/* Subtle ambient lighting */}
      <div className="absolute top-1/3 right-10 w-96 h-96 bg-[#4c121d]/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-80 h-80 bg-[#310b14]/25 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 sm:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-12 border-b border-[#3c1219]/60 pb-8">
          <div>
            <div className="flex items-center gap-3 text-xs uppercase tracking-[0.28em] text-[#d49887] font-medium mb-3 font-sans-clean">
              <span>THE NAIL ATELIER & EDITORIAL BLOG</span>
              <span className="w-12 h-px bg-[#d49887]/60" />
            </div>

            <h2 className="font-editorial text-4xl sm:text-5xl lg:text-6xl text-[#f3ded2] leading-[1.05] tracking-tight">
              Curated nails. <span className="italic font-normal text-[#d49887]">Timeless palettes.</span>
            </h2>
            <p className="text-sm text-[#a67c74] mt-2 max-w-2xl font-light leading-relaxed">
              Explore our editorial manicure lookbooks—from velvet magnetic cat-eye bordeaux to iridescent glazed chrome.
              Every look is published with step-by-step color formulas and pinned directly to our boards.
            </p>
          </div>

          {/* Social Platform Shortcut Buttons */}
          <div className="flex items-center gap-3">
            <button
              onClick={handleOpenPinterest}
              className="group inline-flex items-center gap-2 px-6 py-2.5 bg-[#d49887] hover:bg-[#ecd0c3] text-[#120407] rounded-full text-xs font-semibold uppercase tracking-[0.18em] transition-all shadow-md active:scale-95"
            >
              <Bookmark className="w-3.5 h-3.5 fill-current" />
              <span>PIN BOARDS</span>
              <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </button>

            <button
              onClick={handleOpenThreads}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#250c12] hover:bg-[#34111a] border border-[#d49887]/40 text-[#ecd0c3] rounded-full text-xs font-medium uppercase tracking-[0.18em] transition-all active:scale-95"
            >
              <MessageSquare className="w-3.5 h-3.5 text-[#d49887]" />
              <span>DISCUSS ON THREADS</span>
            </button>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 mb-10">
          <span className="text-[11px] uppercase tracking-wider text-[#a67c74] mr-2">Filter Look:</span>
          {filterOptions.map((opt) => (
            <button
              key={opt.id}
              onClick={() => setActiveFilter(opt.id)}
              className={`px-4 py-1.5 rounded-full text-xs uppercase tracking-wider transition-all ${
                activeFilter === opt.id
                  ? 'bg-[#d49887] text-[#140508] font-semibold shadow-sm'
                  : 'bg-[#1e0a0f] text-[#c59e94] border border-[#3c1219] hover:border-[#d49887]/40 hover:text-[#ecd0c3]'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>

        {/* Nails Gallery Grid (4 Cards) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredNails.map((nail) => {
            const isLiked = likedIds[nail.id];
            return (
              <div
                key={nail.id}
                onClick={() => onSelectNail(nail)}
                className="group cursor-pointer bg-[#1b080d] border border-[#3c1219] hover:border-[#d49887]/50 rounded-2xl overflow-hidden transition-all duration-500 flex flex-col justify-between shadow-lg hover:shadow-2xl hover:shadow-[#3c1219]/40"
              >
                {/* Photo container */}
                <div className="relative aspect-square w-full bg-[#120508] overflow-hidden">
                  <img
                    src={nail.image}
                    alt={nail.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1b080d] via-transparent to-black/30 opacity-60 group-hover:opacity-40 transition-opacity" />

                  {/* Top badges */}
                  <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
                    <span className="px-2.5 py-1 bg-[#120508]/80 backdrop-blur-xs border border-[#d49887]/30 text-[#ecd0c3] text-[10px] uppercase tracking-wider rounded-full font-medium">
                      {nail.shape}
                    </span>

                    <button
                      onClick={(e) => toggleLike(nail.id, e)}
                      className="p-1.5 rounded-full bg-black/50 hover:bg-black/80 text-[#ecd0c3] transition-colors"
                      title="Save to favorites"
                    >
                      <Heart
                        className={`w-3.5 h-3.5 ${
                          isLiked ? 'fill-[#d49887] text-[#d49887]' : 'text-[#ecd0c3]'
                        }`}
                      />
                    </button>
                  </div>

                  {/* Hover Overlay Button */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40 backdrop-blur-[2px]">
                    <span className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#d49887] text-[#140508] text-xs font-semibold uppercase tracking-wider rounded-full shadow-lg">
                      <Bookmark className="w-3.5 h-3.5 fill-current" />
                      <span>View Look & Palette</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>

                {/* Information Footer */}
                <div className="p-5 flex flex-col flex-1 justify-between">
                  <div>
                    <span className="text-[10px] uppercase tracking-[0.2em] text-[#d49887] font-medium block mb-1">
                      {nail.finish}
                    </span>
                    <h3 className="font-serif text-lg text-[#ecd0c3] group-hover:text-[#d49887] transition-colors leading-snug mb-2">
                      {nail.title}
                    </h3>
                    <p className="text-xs text-[#a67c74] line-clamp-2 leading-relaxed">
                      {nail.description}
                    </p>
                  </div>

                  {/* Bottom links */}
                  <div className="mt-4 pt-3 border-t border-[#3c1219] flex items-center justify-between text-xs">
                    <span className="text-[11px] text-[#c59e94] font-light">
                      {nail.palette.split('•')[0]}
                    </span>
                    <span className="inline-flex items-center gap-1 text-[#d49887] group-hover:text-[#ecd0c3] text-[11px] uppercase tracking-wider font-medium">
                      <span>Inspect</span>
                      <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Feature Highlight Box: Nail & Drapery Styling Harmony */}
        <div className="mt-12 bg-[#200a10] border border-[#d49887]/30 rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-[#34111a] border border-[#d49887]/40 flex items-center justify-center text-[#d49887] shrink-0">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-serif text-xl sm:text-2xl text-[#f3ded2] tracking-wide">
                Looking for Custom Nail Formulas & Inspiration?
              </h4>
              <p className="text-xs sm:text-sm text-[#a67c74] mt-1">
                Follow our official Pinterest board for high-res close-ups, nail artist credits, and shoppable gel/chrome sets.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <a
              href={socialLinks.pinterestUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 bg-[#d49887] hover:bg-[#ecd0c3] text-[#140508] rounded-full text-xs font-semibold uppercase tracking-widest transition-all shadow-md active:scale-95"
            >
              <Bookmark className="w-3.5 h-3.5 fill-current" />
              <span>VISIT PINTEREST BOARD</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};
