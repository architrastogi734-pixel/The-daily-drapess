import React from 'react';
import { ArrowRight, Bookmark } from 'lucide-react';
import { CircularStamp } from './CircularStamp';
import { brandImages } from '../data/brandData';
import { SocialLinks } from '../types';

interface HeroSectionProps {
  socialLinks: SocialLinks;
  onOpenSocialModal: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  socialLinks,
}) => {
  const handleOpenPinterest = () => {
    window.open(socialLinks.pinterestUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen pt-28 pb-16 lg:pt-36 lg:pb-24 flex items-center justify-center overflow-hidden bg-[#120508]"
    >
      {/* Ambient background glowing accents */}
      <div className="absolute top-0 right-1/4 w-[500px] h-[500px] bg-[#4a121d]/25 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-[420px] h-[420px] bg-[#310b14]/20 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-5 sm:px-8 w-full relative z-10">
        
        {/* Main Architectural Vertical Rectangle Container */}
        <div className="relative max-w-6xl mx-auto rounded-3xl border border-[#3e131b] bg-[#19060b]/95 backdrop-blur-md p-6 sm:p-10 lg:p-14 shadow-2xl shadow-black/90">
          
          {/* Subtle inner outline for luxury framing */}
          <div className="absolute inset-2 sm:inset-3 rounded-[20px] border border-[#d49887]/10 pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center relative z-10">
            
            {/* Left Column: Brand Name & Navigation Down on the Left (Clean, No Overlap) */}
            <div className="lg:col-span-7 flex flex-col justify-between text-left h-full">
              <div>
                {/* Refined Eyebrow */}
                <div className="flex items-center gap-3 mb-5">
                  <span className="w-8 h-px bg-[#d49887]/80" />
                  <span className="text-[11px] sm:text-xs uppercase tracking-[0.28em] text-[#d49887] font-medium font-sans-clean">
                    STUDIO & EDITORIAL ARCHIVE
                  </span>
                </div>

                {/* The Daily Drapes Brand Name */}
                <h1 className="font-display font-black text-5xl sm:text-6xl md:text-7xl lg:text-8xl text-[#f3ded2] tracking-tight leading-[0.92] uppercase select-none my-2 drop-shadow-md">
                  THE DAILY <br />
                  <span className="font-editorial italic font-normal text-[#d49887]">DRAPES</span>
                </h1>

                {/* Subtitle / Philosophy */}
                <p className="text-sm sm:text-base text-[#c59e94] max-w-md font-light leading-relaxed my-6">
                  Curating elevated brand identities, aesthetic lookbooks, and fluid silhouettes.
                  Explore all source references, manicure palettes, and moodboards directly on Pinterest and Threads.
                </p>

                {/* Pillars */}
                <div className="flex flex-wrap items-center gap-2 text-[11px] sm:text-xs uppercase tracking-[0.25em] text-[#a67c74] font-medium mb-10">
                  <span>BRANDING</span>
                  <span className="text-[#d49887]">•</span>
                  <span>WEB DESIGN</span>
                  <span className="text-[#d49887]">•</span>
                  <span>DIGITAL EXPERIENCES</span>
                </div>
              </div>

              {/* Action Buttons: Down on the left side of the rectangle */}
              <div className="pt-6 border-t border-[#3c1219]/80 mt-auto">
                <div className="flex flex-wrap items-center gap-4">
                  {/* VIEW WORK -> */}
                  <a
                    href="#work"
                    className="group inline-flex items-center gap-3 px-8 py-3.5 bg-[#d49887] hover:bg-[#ecd0c3] text-[#120407] rounded-full text-xs font-semibold tracking-[0.2em] uppercase transition-all duration-300 shadow-xl shadow-[#d49887]/25 active:scale-95"
                  >
                    <span>VIEW WORK</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </a>

                  {/* PINTEREST BOARD */}
                  <button
                    onClick={handleOpenPinterest}
                    className="inline-flex items-center gap-2.5 px-6 py-3.5 bg-[#250c12] hover:bg-[#38121b] border border-[#d49887]/45 text-[#ecd0c3] rounded-full text-xs font-medium tracking-[0.18em] uppercase transition-all shadow-lg active:scale-95"
                  >
                    <Bookmark className="w-3.5 h-3.5 fill-current text-[#d49887]" />
                    <span>PINTEREST BOARD</span>
                  </button>
                </div>

                <div className="mt-6 flex items-center gap-2.5">
                  <span className="w-2 h-2 rounded-full bg-[#d49887] animate-pulse" />
                  <p className="text-[11px] text-[#a67c74] tracking-wider uppercase font-sans-clean">
                    Active Boards • Updated Weekly with Curated Palettes
                  </p>
                </div>
              </div>
            </div>

            {/* Right Column: Photo of the Girl in Vertical Rectangle */}
            <div className="lg:col-span-5 relative flex items-center justify-center">
              
              {/* Circular Atelier Seal at Top Right */}
              <div className="absolute -top-7 -right-3 sm:-top-8 sm:-right-2 z-20">
                <CircularStamp
                  text="DESIGNING WITH PURPOSE & PASSION"
                  icon="flower"
                  size={135}
                />
              </div>

              {/* Vertical Rectangle Photo Frame for the Girl (Clean, No Overlap) */}
              <div className="relative w-full max-w-[360px] sm:max-w-[400px] aspect-[3/4.2] rounded-2xl overflow-hidden border border-[#521824] shadow-2xl shadow-black/90 bg-[#120407]">
                <img
                  src={brandImages.heroModel}
                  alt="The Daily Drapes Editorial Model"
                  className="w-full h-full object-cover object-center filter brightness-[0.98] contrast-[1.03]"
                />
                {/* Subtle bottom gradient vignette */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#140407]/40 via-transparent to-transparent pointer-events-none" />
              </div>

            </div>

          </div>

        </div>

      </div>
    </section>
  );
};

